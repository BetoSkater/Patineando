# Patineando
Ninguna

Editor de textos en línea: https://stackedit.io/app#

# Enlaces de interés:

* https://proandroiddev.com/make-elegant-apps-with-palette-api-c1ca094190eb  
* https://developer.android.com/guide/topics/appwidgets/overview  
  
* Screen slide entre fragments. Creo que justo es lo que necesito  
https://developer.android.com/training/animation/screen-slide  
* EL TUTORIAL TAMBIEN LO PUEDO HACER CON ESTO!!!  
https://blog.mindorks.com/exploring-android-view-pager2-in-android  
https://blog.mindorks.com/exploring-android-view-pager2-in-android  
  
  
* Puede que sea interenate para las imagenes de la cámara:  
 https://stackoverflow.com/questions/21701447/how-to-set-selected-area-of-image-to-imageview  
  
* https://stackoverflow.com/questions/36837356/android-create-clickable-area-on-imageview  
  
* https://living-sun.com/es/android/31461-how-to-set-a-clickable-region-for-an-imageview-android-imageview-clickable.html //TODO Como con un lienzo?  
  
* Justo esto es lo que necesito para la imagen con regiones seleccionables:  
https://stackoverflow.com/questions/16670774/clickable-area-of-image  
	* La que parece emejor respuesta es una en la que pone que se crea un arrayList de objetos area seleccionadas  
https://github.com/LukasLechnerDev/ClickableAreasImages  
https://github.com/Baseflow/PhotoView  
  
* Forma un poco chapuza para conocer las coordenadas de una imagen:  
	* https://stackoverflow.com/questions/8909835/android-how-do-i-get-the-x-y-coordinates-within-an-image-imageview  
	* https://stackoverflow.com/questions/17190576/how-to-get-all-x-and-y-coordinates-of-an-imageview-in-android         