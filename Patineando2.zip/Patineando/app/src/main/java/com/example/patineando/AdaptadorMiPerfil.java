package com.example.patineando;

import androidx.recyclerview.widget.RecyclerView;
//TODO no quiero mostrar una lista de perfiles de usuario en MiPerfil, solo el perfil de dicho usuario en una tarjeta.
/*
public class AdaptadorMiPerfil extends RecyclerView.Adapter<AdaptadorMiPerfil.ViewHolder> {
    public static class ViewHolder extends RecyclerView.ViewHolder{

        //No es un recycler view, es que muestre los datos d eun usuario,
    }
}

 */
